#include<iostream.h>
class phanso
{
	int tu, mau;
	public:
	phanso operator-()
	{
		phanso u;
		u.tu=-tu;
		u.mau=-mau;
		return u;
	}
	void nhap()
	{
		cout<<"Tu=";
		cin>>tu;
		cout<<"Mau=";
		cin>>mau;
	}
	void in()
	{
		cout<<tu<<"/"<<mau;
	}
	friend ostream& operator<<(ostream& os, const phanso &ps);
	friend istream& operator>>(istream& is, phanso &ps)
	{
		cout<<"Tu so:";
		is>>ps.tu;
		cout<<"Mau so:";
		is>>ps.mau;
		return is;
	}
}
;


ostream& operator<<(ostream& os, const phanso &ps)
{
	os<<ps.tu<<"/"<<ps.mau;
	return os;
}

void main()
{
	phanso a, b;
//	cout<<"Nhap phan so la:"<<endl;
	//a.nhap();
	cout<<"Phan so vua nhap:";
	a.in();
	cout<<"Phan so sau khi doi dau";
	a=-a;
	a.in();
	cout<<"Nhap phan so 2 la:";
	cin>>b;
	cout<<"\nPhan so vua nhap la:"<<b;
}
